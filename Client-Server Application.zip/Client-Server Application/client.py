'''This module contains Client info and defines all the functions of the client application'''
import asyncio

print("\t\t\tCLIENT SERVER MANAGEMENT SYSTEM")
UserCommands = []


async def manager_client():
    '''This function defines the client connections with server and its functions.'''
    taker, giver = await asyncio.open_connection('127.0.0.1', 8888)  # 127.0.0.1
    tag = ''

    while 1:
        login_type = input(
            "Enter input command(1-Register, 2-Login, 3-Quit) :")
        try:
            ussr = "user"
            if login_type == "1":
                promted_cmd = (
                    input("Enter input command \n    register <username> <password> :"))
                UserCommands.append(promted_cmd)
                promted_cmd = promted_cmd.split(' ')
                if promted_cmd[0] != "register":
                    print("Command is wrong")
                elif ussr == "admin":
                    print("Registration is not done")
                else:
                    tag = " ".join(map(str, promted_cmd))
                    giver.write(tag.encode())
                    context = await taker.read(100)
                    print(f'Received data: \n{context.decode()}')
                continue
            elif login_type == "2":
                promted_cmd = input(
                    "Enter input command\n    login <username> <password> :")
                UserCommands.append(promted_cmd)
                promted_cmd = promted_cmd.split(' ')
                try:
                    if promted_cmd[0] != "login":
                        print(" Command is wrong ")
                    else:
                        tag = " ".join(map(str, promted_cmd))
                        giver.write(tag.encode())
                        context = await taker.read(100)
                        context = context.decode()
                        print('*' * 100)
                        print(f'Received data: \n{context}')
                        print('*' * 100, '\n')
                        if "Login succesful - user" in context or 'User already logged in' in context:
                            break
                        else:
                            continue
                except:
                    SystemError
            elif login_type == "3":
                promted_cmd = input("Enter input command\n    quit:")
                UserCommands.append(promted_cmd)
                promted_cmd = promted_cmd.split(' ')
                try:
                    if promted_cmd[0] != "quit":
                        print(" Command is wrong ")
                        continue
                    else:
                        tag = promted_cmd[0]
                        giver.write(tag.encode())
                        context = await taker.read(100)
                        print(f'Received  data: \n{context.decode()}')
                        quit()
                except IndexError:
                    print("Index error occurs")

            else:
                context = "Enter right option"
                print(f'Received data: \n{context}')
                continue
        except NameError:
            print("Name error occurred")

    def commands():
        '''This function explains about the available commands and their usages'''
        print('''             --------COMMANDS LIST----------
    -> register <username> <password> --> registers a new client in the server using the username,password provided.

    -> login <username> <password> --> It helps clients to login into the server.

    -> quit --> It logout the user from server.

    -> create_folder <name> --> It creates a new folder with specified name in the working directory.

    -> change_folder <name> --> It moves the working directory in the current folder.

    -> list --> This command prints the list of all files and folders.

    -> read_file <name> --> It returns the file which is provided.

    -> write_file <name> <input> --> It writes the context at the end of the file.

    -> commands --> It displays all the available commands.
        ''')

    commands()
    var = 1
    while var:
        promted_cmd = input("Enter command:")
        UserCommands.append(promted_cmd)
        promted_cmd = promted_cmd.split(' ')
        try:
            ussr = "user"
            if len(promted_cmd) == 1:
                """if promted_cmd[0] == "register" or promted_cmd[0] == "login":
                    print(
                        "Cannot register or login another user while already loggedin")
                    continue"""
                if promted_cmd[0] == "commands":
                    commands()
                    continue
                elif ussr == "admin":
                    print("Commands not cleared")
                elif ussr == "not admin":
                    print("commands cannot be cleared")
                elif promted_cmd[0] == "quit":
                    tag = promted_cmd[0]
                    giver.write(tag.encode())
                    context = await taker.read(100)
                    print(f'Response: {context.decode()}')
                    quit()
                else:
                    tag = " ".join(map(str, promted_cmd))
                    giver.write(tag.encode())
                    context = await taker.read(2048)
                    print(f'Response: \n{context.decode()}')
                    continue
            else:
                """if promted_cmd[0] == "register" or promted_cmd[0] == "login":
                    print(
                        "Cannot register or login another user while already loggedin")
                    continue"""
                if promted_cmd[0] == "commands":
                    try:
                        if promted_cmd[1] == "history":
                            print(" LIST OF ALL AVAILABLE COMMANDS ")
                            tem = len(UserCommands)
                            for i in range(tem):
                                print("COMMAND", i + 1, ":", UserCommands[i])
                            continue
                        elif promted_cmd[1] == "clear":
                            UserCommands.clear()
                            print("COMMANDS CLEARED")
                            continue
                    except FileNotFoundError:
                        print("File not found error")

                elif promted_cmd[0] == "quit":
                    tag = promted_cmd[0]
                    giver.write(tag.encode())
                    context = await taker.read(100)
                    print(f'Response: {context.decode()}')
                    quit()
                else:
                    tag = " ".join(map(str, promted_cmd))
                    giver.write(tag.encode())
                    context = await taker.read(2048)
                    print(f'Response: \n{context.decode()}')
                    continue
            continue
        except OSError:
            print("Operating system error")

asyncio.run(manager_client())
