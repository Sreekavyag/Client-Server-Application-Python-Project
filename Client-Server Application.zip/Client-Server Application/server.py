''' This Modules acts as server to process the client requests running on localhost:8080'''
import asyncio
import utilities as util


async def server_handling(reader, writer):
    '''
    This Function enables the connection between client and server and performs read and write operations.
    The given commands are preprocessed and respective functions are called.

    Parameters:
    reader:
        Perform read operations.
    writer:
        Perform write operations.
    '''

    ip_addr = writer.get_extra_info('peername')
    feedback = f"{ip_addr} address is connected to the server"
    print(feedback)
    var = True
    while var:
        info = await reader.read(100)
        feedback = info.decode().strip()
        print(f"Received feedback: {feedback}\nfrom ip address: {ip_addr}")
        feedback = feedback.split(' ')
        try:
            if 'register' in feedback:
                feedback = util.register(feedback, ip_addr)

            elif "login" in feedback:
                feedback = util.login(feedback, ip_addr)

            elif "delete" in feedback:
                feedback = util.delete(feedback, ip_addr)

            elif "list" in feedback:
                feedback = util.lists(ip_addr)

            elif "create_folder" in feedback:
                feedback = util.create_folder(feedback, ip_addr)

            elif "write_file" in feedback:
                feedback = util.write_file(feedback, ip_addr)

            elif "change_folder" in feedback:
                feedback = util.change_folder(feedback, ip_addr)

            elif "read_file" in feedback:
                feedback = util.read_file(feedback, ip_addr)

            elif "quit" in feedback:
                feedback = "Exits the connection from server"
                try:
                    del util.LOGGED_USERS_ADDRESS[ip_addr[1]]
                    del util.WORKING_DIR[ip_addr[1]]
                    del util.LOGGEDUSERS[ip_addr[1]]
                    del util.FILEREADERPOINTER_LOC[ip_addr[1]]

                except KeyError:
                    pass
                finally:
                    msge = "".join(str(str_var) for str_var in feedback)
                    writer.write(msge.encode())
                    break
            else:
                feedback = "Please enter valid choice"
                msge = "".join(str(str_var) for str_var in feedback)
                print(f"Send: {msge}")
                writer.write(msge.encode())
        except:
            msge = "unexpected error occured"
        msge = "".join(str(str_var) for str_var in feedback)
        print(f"Send: {msge}")
        writer.write(msge.encode())


async def main():
    ''' This function is responsible for the initiation of the server program.'''
    server = await asyncio.start_server(server_handling, '127.0.0.1', 8888)

    ip_addr = server.sockets[0].getsockname()
    print(f'Serving on the ip address: {ip_addr}')

    async with server:
        await server.serve_forever()

asyncio.run(main())
