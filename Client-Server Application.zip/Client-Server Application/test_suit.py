﻿""" This is the test_suit python file to perform the unit-testing."""
import unittest
import warnings
import utilities as util

warnings.filterwarnings('ignore')


class TestSuit(unittest.TestCase):
    """TestSuit class performs all required unit tests
    Below Methods will be called automatically 
    and test report will be asserted if any of the test fails:
    <<<<---------------------->>>>
    test1_user_registeration(self):
        This is used to do unit testing for the newly registered users.
    test2_login(self):
        This is used to do unit testing for the existing users.
    test3_create_folder(self):
        This is used to do unit testing for the creation of the folders.
       """

    def test1_user_registeration(self):
        """This function is used to do unit testing for users whos registered for the first time.
        """
        input_vals = [[["register", "user1", "123"], ('127.0.0.1', 98725)],
                      [["register", "kavya", "123"], ('127.0.0.1', 14325)],
                      [["register", "kavya", "1234"], ('127.0.0.1', 14325)]]
        exp_outputs = ["Profile created successfully", "Username already exists",
                       "Username already exists"]
        result = [util.register(i[0], i[1]) for i in input_vals]
        # print(result,'\n','='*100,'\n', exp_outputs)
        # print('*'*100)
        self.assertListEqual(result, exp_outputs)

    def test2_login(self):
        """This is used to do unit testing for already existing users
            TestCase1: Login with incorrect credentials - incorrect password
            TestCase2: Login with incorrect credentials, incorrect username
        """
        input_vals = [[["login", "kavya", "123"], ('127.0.0.1', 12345)],
                      [["login", "hello", "123"], ('127.0.0.1', 14325)]]
        exp_outputs = [
            'Login Unsuccesful - Wrong Password', 'Username does not exist']
        result = [util.login(i[0], i[1]) for i in input_vals]
        # print(result, '\n', '=' * 100, '\n', exp_outputs)
        self.assertListEqual(result, exp_outputs)

    def test3_create_folder(self):
        """This is used to do unit testing for the creation of the folders.
             TestCase1: Create Folder for user in root folder
        """
        input_vals = [[["create_folder", "studies"], ('127.0.0.1', 98725)]]
        exp_outputs = ['Folder cannot be created in ROOT folder']
        result = [util.create_folder(i[0], i[1]) for i in input_vals]
        # print(result, '\n', '=' * 100, '\n', exp_outputs)
        self.assertListEqual(result, exp_outputs)


if __name__ == '__main__':
    unittest.main(failfast=True, exit=False)
