﻿'''This module contains all the helper functions which user wants to perform on the server'''
import signal
import os
import time

# Global varaibles
LOGGEDUSERS = []
LOGGED_USERS_ADDRESS = {}
ROOT_DIR = os.getcwd()
WORKING_DIR = {}
FILEWRITERPOINTER_LOC, FILEREADERPOINTER_LOC = {}, {}


signal.signal(signal.SIGINT, signal.SIG_DFL)


def register(user_command, ipaddress):
    '''
    This function is used to register a new clients.

    Parameters:
    <<<<----------->>>>
    user_command:
        This contains details of user - [register, <Username>, <Password>]
    ipaddress:
        It is a bundle of the ip address and the port of the client.
    '''

    path = f"{ROOT_DIR}\\user.txt"

    # Reading All Users details
    registered_users = open(path, "r")
    users = registered_users.read()
    users = users.split("\n")
    registered_users.close()

    # checking if user already exists or not
    for i in range(0, len(users)):
        if not len(users):
            continue
        if user_command[1] == users[i].split(' ')[0]:
            results = "Username already exists"
            return results

    # adding entry to users list
    registered_users = open(path, "a+")
    registered_users.write("\n"+" ".join(user_command[1:]))
    registered_users.close()

    # creating directory for the registered user
    path = f'{ROOT_DIR}' + os.sep + user_command[1]
    try:
        os.mkdir(path)
    except FileExistsError:
        results = "Username already exists"
        return results

    # Updating the working directory for new user
    WORKING_DIR[ipaddress[1]] = {user_command[1]: str(path)}
    results = "Profile created successfully"

    return results


def login(user_command, ipaddress):
    '''
    This Function allows a client to login to the server.
    Client can access personal folder as starting point to work only if login success.

    Parameters:
    <<<<----------->>>>
    user_command:
        It is the command given by the client to the server.
    ipaddress:
        It is a bundle of the ip address and the port of the client.
    '''
    if user_command[1] not in LOGGEDUSERS:

        path = f"{ROOT_DIR}\\user.txt"
        # Reading All Users details
        registered_users = open(path, "r")
        users = registered_users.read()
        users = users.split("\n")
        registered_users.close()

        for i in range(0, len(users)):
            user_details = users[i].split()
            if not len(user_details):
                continue
            if user_command[1] == user_details[0]:
                if user_command[2] == user_details[1]:
                    results = f"Login succesful - user"
                    path = f'{ROOT_DIR}'
                    os.chdir(path)
                    os.chdir(user_command[1])
                    LOGGEDUSERS.append(user_command[1])
                    LOGGED_USERS_ADDRESS[ipaddress[1]] = {
                        user_command[1]: 'user'}

                    WORKING_DIR[ipaddress[1]] = {
                        user_command[1]: str(os.getcwd())}
                    return results

                results = "Login Unsuccesful - Wrong Password"
                return results

        results = "Username does not exist"
        return results

    results = "User already logged in"
    return results


def lists(ipaddress):
    '''
    Lists all the Files in the present working Directory of the client.

    Parameters:
    <<<<----------->>>>
    ipaddress:
        The ip address and the port number of the client.

    Output:
        Returns all the File and Folders present in current working directory
    '''

    for i in WORKING_DIR[ipaddress[1]].keys():
        working_directory = str(WORKING_DIR[ipaddress[1]][i])

    files_ = os.listdir(working_directory)
    file_list = ["NAME", "SIZE", "CREATION TIME"]
    new_list = []
    if len(files_) == 0:
        return " No Files found "

    for lst in files_:
        stat_lst = os.stat(lst)
        new_list.append(
            [lst, stat_lst.st_size, time.ctime(stat_lst.st_mtime)])
        data = "\n".join(str(s) for s in new_list)
    print(type(file_list))
    file_list = str(file_list)
    print(type(data))
    return (file_list+"\n"+data)


def create_folder(user_command, ipaddress):
    '''
    This function creates a new folder in the present working Directory of the client.
    Folder willn't be created if the name of folder already exists.

    Parameters:
    <<<<----------->>>>
    user_command:
        The command given to the server by the client.
    ipaddress:
        The ip address and the port number of the client.
    '''
    try:
        if os.getcwd() == ROOT_DIR:
            results = "Folder cannot be created in ROOT folder"
            assert results is not None
            return results
        # Fetching Current working directory for the given user using ipaddress
        for i in WORKING_DIR[ipaddress[1]].keys():
            user_work_dir = str(WORKING_DIR[ipaddress[1]][i])

        # Checking if folder already exists
        list_of_dirs = os.listdir(user_work_dir)
        list_of_dirs = [i for i in list_of_dirs if not os.path.isfile(i)]
        for i in range(0, len(list_of_dirs)):
            if list_of_dirs[i] == user_command[1]:
                results = "Folder name already exists"
                assert results is not None
                return results

        # Creating folder
        os.chdir(user_work_dir)
        os.mkdir(user_command[1])
        results = "Folder created"
        assert results is not None
        return results

    except OSError:
        results = "OS error occured"
        return results
    except AssertionError:
        results = 'Unable to process the Request'
        return results


def change_folder(user_command, ipaddress):
    '''
    Moves the current working directory(CWD) to the specified fldr residing in the current fldr.
    To go back to the previous folder, a name of two dots (..) is used after the command. 

    Parameters:
    <<<<----------->>>>
    user_command:
        The command given to the server by the client.
    ipaddress:
        The ip address and the port number of the client.
    '''

    # Fetching Current working directory for the given user using ipaddress
    for i in WORKING_DIR[ipaddress[1]].keys():
        user_work_dir = str(WORKING_DIR[ipaddress[1]][i])

    # Changing to working directory
    os.chdir(user_work_dir)

    if user_command[1] == "..":
        if os.getcwd() == ROOT_DIR:
            results = "Doesn't have access to move back from ROOT folder"
            return results

        os.chdir("..")
        for i in WORKING_DIR[ipaddress[1]].keys():
            WORKING_DIR[ipaddress[1]] = {i: str(os.getcwd())}
        results = "Current working Directory moved back to previous"
        return results

    if user_work_dir == ROOT_DIR:
        # Checking if user has permission to access
        for username in LOGGED_USERS_ADDRESS[ipaddress[1]].keys():
            if user_command[1] == username:
                os.chdir(user_command[1])
                for i in WORKING_DIR[ipaddress[1]].keys():
                    WORKING_DIR[ipaddress[1]] = {i: str(os.getcwd())}
                results = "Current working Directory changed"
                return results
        results = "Permission denied to access this folder"
        return results

    try:
        os.chdir(user_command[1])
        for i in WORKING_DIR[ipaddress[1]].keys():
            WORKING_DIR[ipaddress[1]] = {i: str(os.getcwd())}
        results = "Current working Directory changed"
        return results
    except FileNotFoundError:
        results = "Folder not found"
        return results


def write_file(user_command, ipaddress):
    '''
    This function is used for writing data into file at the end in current working Directory, starting on a new line.
    If the file doesn't exists with the given name, new File will be created in the current working directory(CWD).

    Parameters:
    <<<<----------->>>>
    user_command:
        The command given to the server by the client.
    ipaddress:
        The ip address and the port number of the client.
    '''

    # Fetching Current working directory for the given user using ipaddress
    for i in WORKING_DIR[ipaddress[1]].keys():
        user_work_dir = str(WORKING_DIR[ipaddress[1]][i])

    try:
        os.chdir(user_work_dir)
        if len(user_command) == 1:
            results = "File name is not specified in the command"
            return results

        if len(user_command) <= 2:
            try:
                f_a = open(user_command[1], "w")
                f_a.write("")
                f_a.close()
                results = "File created"
            except PermissionError:
                results = "Permission denied to open the file"
        else:
            try:
                f_a = open(user_command[1], "a+")
                f_a.write("\n")
                f_a.write(' '.join(user_command[2:]))
                f_a.close()
                results = "File writing complete"
            except PermissionError:
                results = "Permission denied to open the File"
        return results
    except AssertionError:
        results = 'Unable to process the Request'
        return results


def read_file(user_command, ipaddress):
    '''
    This function is used for reading data from the file specified by the user from the current working Directory(CWD),
    return hundred characters for every request.
     In each subsequent call by the same client will return the next 100 chars from the file,
    up until all chars are read. 
    If in case a service request without a name will close the currently opened file from reading.

    Parameters:
    <<<<----------->>>>
    user_command:
        The command given to the server by the client .
    ipaddress:
        The ip address and the port number of the client.
    '''

    # Fetching Current working directory for the given user using ipaddress
    for i in WORKING_DIR[ipaddress[1]].keys():
        user_work_dir = WORKING_DIR[ipaddress[1]][i]

    os.chdir(user_work_dir)
    user_work_dir = os.getcwd()
    # adding reeader pointer for all logined users
    try:
        if ipaddress[1] not in FILEREADERPOINTER_LOC:
            FILEREADERPOINTER_LOC[ipaddress[1]] = {repr(user_work_dir): []}

        # Track which all files are read already
        FILESREAD = FILEREADERPOINTER_LOC[ipaddress[1]][repr(user_work_dir)]

    except KeyError:
        return 'Failed'

    try:
        if len(user_command) == 1:
            FILEREADERPOINTER_LOC[ipaddress[1]] = {repr(user_work_dir): []}
            results = "File name is not specified in the command"
            return results
        else:
            # Checking is File is read already by the user
            if user_command[1] in FILESREAD:
                last_pointer = FILEREADERPOINTER_LOC[ipaddress[1]][repr(
                    user_work_dir)][user_command[1]]
                file_pointer = open(user_command[1], "r")
                file_info = str(file_pointer.read())
                if last_pointer + 1 >= len(file_info):
                    FILEREADERPOINTER_LOC[ipaddress[1]][repr(user_work_dir)] = {
                        user_command[1]: 0}
                    return "Reached End of the File"

                if last_pointer + 100 <= len(file_info):
                    data = file_info[last_pointer: last_pointer + 100]
                    FILEREADERPOINTER_LOC[ipaddress[1]][repr(user_work_dir)] = {
                        user_command[1]: last_pointer + 100}
                    return data
                else:
                    data = file_info[last_pointer:]
                    FILEREADERPOINTER_LOC[ipaddress[1]][repr(user_work_dir)] = {
                        user_command[1]: 0}
                    return data
            else:
                try:
                    # Checking if file is present in the user folder
                    list_of_Files = os.listdir(os.getcwd())
                    list_of_Files = [
                        i for i in list_of_Files if os.path.isfile(i)]
                    if user_command[1] in list_of_Files:
                        file_pointer = open(user_command[1], "r")
                        file_info = str(file_pointer.read())
                        if len(file_info) > 100:
                            data = file_info[0: 100]
                            FILEREADERPOINTER_LOC[ipaddress[1]][repr(user_work_dir)] = {
                                user_command[1]: 100}
                            assert data is not None
                            return data
                        elif len(file_info) == 0:
                            results = "File is empty"
                            assert results is not None
                            return results
                        else:
                            data = file_info
                            FILEREADERPOINTER_LOC[ipaddress[1]][repr(user_work_dir)] = {
                                user_command[1]: len(file_info)}
                            return data

                    elif user_command[1] == '':
                        FILEREADERPOINTER_LOC[ipaddress[1]
                                              ][repr(user_work_dir)] = {}
                        results = "File is closed"
                        assert results is not None
                        return results
                    else:
                        results = "File doesn't exist"
                        assert results is not None
                        return results
                except PermissionError:
                    results = "Permission denied to read this File"
                    return results
                except AssertionError:
                    results = 'Unable to process the Request'
                    return results
    except Exception as e:
        results = 'Unable to process the Request'
        return results
